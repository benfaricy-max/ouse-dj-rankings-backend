function normalize(value, min, max) {
  if (max === min) return 0;
  return ((value - min) / (max - min)) * 100;
}

function scoreArtists(artists) {
  const metrics = [
    "spotify_followers",
    "spotify_popularity",
    "spotify_playlist_placements",
    "spotify_follower_growth_rate",
    "spotify_avg_track_popularity",
    "youtube_subscribers",
    "youtube_total_views",
    "google_trends_score",
    "manual_scene_score",
  ];

  // Build min/max range for each metric across all artists
  const ranges = {};
  for (const m of metrics) {
    const values = artists.map((a) => a[m] || 0);
    ranges[m] = { min: Math.min(...values), max: Math.max(...values) };
  }

  // Weights must sum to 1.0
  const weights = {
    spotify_followers:            0.10,
    spotify_popularity:           0.15,
    spotify_playlist_placements:  0.15,
    spotify_follower_growth_rate: 0.10,
    spotify_avg_track_popularity: 0.10,
    youtube_subscribers:          0.10,
    youtube_total_views:          0.10,
    google_trends_score:          0.10,
    manual_scene_score:           0.10,
  };

  return artists
    .map((artist) => {
      let score = 0;
      for (const [metric, weight] of Object.entries(weights)) {
        const norm = normalize(
          artist[metric] || 0,
          ranges[metric].min,
          ranges[metric].max
        );
        score += norm * weight;
      }
      return { ...artist, score: Math.round(score * 10) / 10 };
    })
    .sort((a, b) => b.score - a.score)
    .map((artist, i) => ({ ...artist, rank: i + 1 }));
}

module.exports = { scoreArtists };
