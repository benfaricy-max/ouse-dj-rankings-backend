const express = require("express");
const cors = require("cors");
const cron = require("node-cron");
require("dotenv").config();

const { getSpotifyToken, getSpotifyData, getSpotifyTopTracks, getYouTubeData } = require("./fetchArtist");
const { getPlaylistPlacements } = require("./fetchSpotifyPlaylists");
const { getGoogleTrends } = require("./fetchTrends");
const { scoreArtists } = require("./score");
const { saveSnapshot, getLastWeekSnapshot } = require("./db");
const artists = require("./artists.json");

const app = express();

app.use(cors({
  origin: [
    "http://localhost:5173",
    // Add your Vercel URL here once deployed, e.g.:
    // "https://your-app.vercel.app",
    // "https://yourdomain.com",
  ],
}));

app.use(express.json());

// Cache rankings in memory so repeated frontend requests don't re-hit all APIs
let cachedRankings = null;
let lastFetchedAt = null;
const CACHE_TTL_MS = 1000 * 60 * 60; // 1 hour

async function buildRankings() {
  console.log("Building rankings...", new Date().toISOString());
  const token = await getSpotifyToken();

  const enriched = await Promise.all(
    artists.map(async (artist) => {
      try {
        const [spotify, topTracks, youtube, playlists, trends] = await Promise.all([
          getSpotifyData(artist.spotify_id, token),
          getSpotifyTopTracks(artist.spotify_id, token),
          getYouTubeData(artist.youtube_channel_id),
          getPlaylistPlacements(artist.spotify_id, token),
          getGoogleTrends(artist.name),
        ]);

        // Calculate week-over-week follower growth rate
        const lastWeek = getLastWeekSnapshot(artist.name);
        const growthRate =
          lastWeek && lastWeek.spotify_followers > 0
            ? ((spotify.spotify_followers - lastWeek.spotify_followers) /
                lastWeek.spotify_followers) *
              100
            : 0;

        const data = {
          ...artist,
          ...spotify,
          ...topTracks,
          ...youtube,
          ...playlists,
          google_trends_score: trends.score,
          google_trends_direction: trends.direction,
          spotify_follower_growth_rate: Math.round(growthRate * 100) / 100,
          manual_scene_score: artist.manual_scene_score || 0,
        };

        saveSnapshot(artist.name, data);
        return data;
      } catch (err) {
        console.error(`Failed to fetch data for ${artist.name}:`, err.message);
        // Return artist with zeroed metrics so one failure doesn't crash everything
        return {
          ...artist,
          spotify_followers: 0,
          spotify_popularity: 0,
          spotify_avg_track_popularity: 0,
          spotify_top_track_score: 0,
          spotify_playlist_placements: 0,
          spotify_playlists_found: [],
          spotify_follower_growth_rate: 0,
          youtube_subscribers: 0,
          youtube_total_views: 0,
          google_trends_score: 0,
          google_trends_direction: "flat",
          manual_scene_score: artist.manual_scene_score || 0,
        };
      }
    })
  );

  const ranked = scoreArtists(enriched);
  cachedRankings = ranked;
  lastFetchedAt = Date.now();
  console.log("Rankings built successfully.");
  return ranked;
}

// Main rankings endpoint
app.get("/api/rankings", async (req, res) => {
  try {
    const isCacheValid = cachedRankings && lastFetchedAt && (Date.now() - lastFetchedAt < CACHE_TTL_MS);
    if (isCacheValid) {
      return res.json({ rankings: cachedRankings, cached: true, lastFetchedAt });
    }
    const rankings = await buildRankings();
    res.json({ rankings, cached: false, lastFetchedAt });
  } catch (err) {
    console.error("Rankings error:", err);
    res.status(500).json({ error: "Failed to build rankings" });
  }
});

// Health check endpoint — useful for Railway/Render to confirm the server is up
app.get("/health", (req, res) => {
  res.json({ status: "ok", lastFetchedAt });
});

// Refresh endpoint — call this manually to force a fresh fetch
app.post("/api/refresh", async (req, res) => {
  try {
    const rankings = await buildRankings();
    res.json({ success: true, rankings });
  } catch (err) {
    console.error("Refresh error:", err);
    res.status(500).json({ error: "Refresh failed" });
  }
});

// Weekly cron job — runs every Monday at 6am UTC
cron.schedule("0 6 * * 1", async () => {
  console.log("Running weekly rankings refresh...");
  await buildRankings();
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  // Build rankings on startup so first request is fast
  buildRankings().catch(console.error);
});
