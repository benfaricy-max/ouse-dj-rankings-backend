const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "data", "snapshots.json");

function loadSnapshots() {
  if (!fs.existsSync(DB_PATH)) return {};
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
  } catch {
    return {};
  }
}

function saveSnapshot(artistName, data) {
  const snapshots = loadSnapshots();
  if (!snapshots[artistName]) snapshots[artistName] = [];

  snapshots[artistName].push({
    spotify_followers: data.spotify_followers,
    spotify_popularity: data.spotify_popularity,
    youtube_subscribers: data.youtube_subscribers,
    timestamp: new Date().toISOString(),
  });

  // Keep last 52 weeks only
  if (snapshots[artistName].length > 52) {
    snapshots[artistName].shift();
  }

  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(snapshots, null, 2));
}

function getLastWeekSnapshot(artistName) {
  const snapshots = loadSnapshots();
  const history = snapshots[artistName] || [];
  return history.length >= 2 ? history[history.length - 2] : null;
}

module.exports = { saveSnapshot, getLastWeekSnapshot };
