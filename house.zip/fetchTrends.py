import sys
import json

artist_name = sys.argv[1]

try:
    from pytrends.request import TrendReq

    pytrends = TrendReq(hl="en-US", tz=360)
    pytrends.build_payload([artist_name], timeframe="now 7-d")
    data = pytrends.interest_over_time()

    if data.empty:
        print(json.dumps({"score": 0, "direction": "flat"}))
    else:
        values = data[artist_name].tolist()
        avg = sum(values) / len(values)
        if values[-1] > values[0]:
            direction = "up"
        elif values[-1] < values[0]:
            direction = "down"
        else:
            direction = "flat"
        print(json.dumps({"score": round(avg, 1), "direction": direction}))

except Exception as e:
    # Return zeroed result on any failure so the rest of scoring still works
    print(json.dumps({"score": 0, "direction": "flat", "error": str(e)}))
