const axios = require("axios");

// Key house music editorial playlists on Spotify
// Verify these IDs are current at open.spotify.com as they can occasionally change
const EDITORIAL_PLAYLISTS = {
  mint:                "37i9dQZF1DX4dyzvuaRJ0n",
  friday_cratediggers: "37i9dQZF1DX8dTWjpijlub",
  deep_house_relax:    "37i9dQZF1DX2TRYkJECvfC",
  hot_in_house:        "37i9dQZF1DX6J5NfMJS675",
};

async function getPlaylistPlacements(artistId, token) {
  let placements = 0;
  const playlistsFound = [];

  for (const [name, playlistId] of Object.entries(EDITORIAL_PLAYLISTS)) {
    try {
      const res = await axios.get(
        `https://api.spotify.com/v1/playlists/${playlistId}/tracks`,
        {
          headers: { Authorization: `Bearer ${token}` },
          params: { limit: 100 },
        }
      );

      const tracks = res.data.items || [];
      const found = tracks.some((item) =>
        item.track?.artists?.some((a) => a.id === artistId)
      );

      if (found) {
        placements++;
        playlistsFound.push(name);
      }
    } catch (err) {
      console.warn(`Playlist check failed for ${name}:`, err.message);
    }
  }

  return {
    spotify_playlist_placements: placements,
    spotify_playlists_found: playlistsFound,
  };
}

module.exports = { getPlaylistPlacements };
