# House DJ Rankings — Backend

## Setup

### 1. Install Node dependencies
```bash
npm install
```

### 2. Install Python dependency for Google Trends
```bash
pip install pytrends
```

### 3. Create your .env file
Create a file called `.env` in this folder (never commit this to GitHub):
```
SPOTIFY_CLIENT_ID=your_spotify_client_id
SPOTIFY_CLIENT_SECRET=your_spotify_client_secret
YOUTUBE_API_KEY=your_youtube_api_key
```

### 4. Fill in artists.json
Replace all `REPLACE_WITH_REAL_SPOTIFY_ID` and `REPLACE_WITH_REAL_YOUTUBE_CHANNEL_ID` values with real IDs.

- Spotify artist ID: found in the artist's Spotify URL, e.g. `open.spotify.com/artist/4oLeXFyACqeem2VImYeBFe`
- YouTube channel ID: found in the channel's URL or via YouTube Studio

### 5. Run locally
```bash
npm run dev
```

Server runs on http://localhost:3001

## Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/rankings` | GET | Returns ranked artist list (cached for 1 hour) |
| `/api/refresh` | POST | Forces a fresh data fetch |
| `/health` | GET | Health check |

## Deployment (Railway)

1. Push this folder to a GitHub repo
2. Connect the repo to Railway
3. Add environment variables in Railway dashboard
4. Railway auto-deploys on every push
