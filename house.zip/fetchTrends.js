const { exec } = require("child_process");
const path = require("path");

function getGoogleTrends(artistName) {
  return new Promise((resolve) => {
    const scriptPath = path.join(__dirname, "fetchTrends.py");
    // Sanitize artist name to prevent shell injection
    const safeName = artistName.replace(/[^a-zA-Z0-9 _-]/g, "");

    exec(`python3 "${scriptPath}" "${safeName}"`, (error, stdout, stderr) => {
      try {
        const result = JSON.parse(stdout);
        resolve(result);
      } catch {
        console.warn(`Google Trends parse failed for ${artistName}:`, stderr);
        resolve({ score: 0, direction: "flat" });
      }
    });
  });
}

module.exports = { getGoogleTrends };
