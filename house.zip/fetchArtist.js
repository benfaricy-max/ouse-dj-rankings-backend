const axios = require("axios");
require("dotenv").config();

async function getSpotifyToken() {
  const credentials = Buffer.from(
    `${process.env.SPOTIFY_CLIENT_ID}:${process.env.SPOTIFY_CLIENT_SECRET}`
  ).toString("base64");

  const res = await axios.post(
    "https://accounts.spotify.com/api/token",
    "grant_type=client_credentials",
    {
      headers: {
        Authorization: `Basic ${credentials}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
    }
  );
  return res.data.access_token;
}

async function getSpotifyData(artistId, token) {
  const res = await axios.get(
    `https://api.spotify.com/v1/artists/${artistId}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  return {
    name: res.data.name,
    spotify_followers: res.data.followers.total,
    spotify_popularity: res.data.popularity,
    spotify_url: res.data.external_urls.spotify,
    image: res.data.images[0]?.url || null,
  };
}

async function getSpotifyTopTracks(artistId, token) {
  const res = await axios.get(
    `https://api.spotify.com/v1/artists/${artistId}/top-tracks`,
    {
      headers: { Authorization: `Bearer ${token}` },
      params: { market: "US" },
    }
  );

  const tracks = res.data.tracks;
  if (!tracks || tracks.length === 0) {
    return { spotify_avg_track_popularity: 0, spotify_top_track_score: 0 };
  }

  const avgTrackPopularity =
    tracks.reduce((sum, t) => sum + t.popularity, 0) / tracks.length;

  return {
    spotify_avg_track_popularity: Math.round(avgTrackPopularity),
    spotify_top_track_score: tracks[0]?.popularity || 0,
  };
}

async function getYouTubeData(channelId) {
  const res = await axios.get(
    "https://www.googleapis.com/youtube/v3/channels",
    {
      params: {
        part: "statistics,snippet",
        id: channelId,
        key: process.env.YOUTUBE_API_KEY,
      },
    }
  );

  const channel = res.data.items?.[0];
  if (!channel) {
    return { youtube_subscribers: 0, youtube_total_views: 0 };
  }

  return {
    youtube_subscribers: parseInt(channel.statistics.subscriberCount) || 0,
    youtube_total_views: parseInt(channel.statistics.viewCount) || 0,
  };
}

module.exports = {
  getSpotifyToken,
  getSpotifyData,
  getSpotifyTopTracks,
  getYouTubeData,
};
